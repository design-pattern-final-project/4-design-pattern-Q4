/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package StudentInfoSystem;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class StudentImp implements Student{ 
 Student_Info si;
 Database db =  Database.getInstance() ;
 

//  public ArrayList<Student_info> getStudinfo() throws SQLException{
//          if(db.Connect()){
//            Student_info info;
//            
//      String query = "SELECT * FROM admin";
//       ResultSet rs ;
//       rs=db.select(query);
//      
//       while(rs.next()){
//          
//               info=new Student_info(rs.getString("id"),rs.getString("first_name"),rs.getString("last_name"),rs.getInt("age"),rs.getString("course_code"),rs.getString("email"),rs.getString("address"));
//                infolist.add(info);
//      }
//  
//        
//        
//        }
//        return infolist;
//  }

@Override
    public void delete() {
        if(db.Connect()){
            Student_Info info;
            
      String query = "DELETE * FROM admin";
//       ResultSet rs ;
        int rs=db.query(query);
      
        }
      
    }
@Override
    public ArrayList<Student_Info> getStudinfo() {
    ArrayList<Student_Info > infolist = new ArrayList<>(); 
        if(db.Connect()){
            Student_Info info;
            
      String query = "SELECT * FROM admin";
       ResultSet rs ;
       rs=db.select(query);
      
            try {
                while(rs.next()){
                    
                    info=new Student_Info(rs.getString("id"),rs.getString("first_name"),rs.getString("last_name"),rs.getInt("age"),rs.getString("course_code"),rs.getString("email"),rs.getString("address"));
                    infolist.add(info);
                }     } catch (SQLException ex) {
                Logger.getLogger(StudentImp.class.getName()).log(Level.SEVERE, null, ex);
            }
  
        
        
        }
        return infolist;
    }
  
  
}
