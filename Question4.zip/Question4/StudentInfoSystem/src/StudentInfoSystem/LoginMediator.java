/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package StudentInfoSystem;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;


public class LoginMediator {
    ArrayList<Student_Info > login = new ArrayList<>();
    Student_Info si;
 Database db =  Database.getInstance() ;
 public String UserName;
 public String Password;
   public ArrayList<Student_Info > getAllCustomers() throws SQLException 
{
  if(db.Connect()){
       String s = "SELECT * FROM login"; 
       ResultSet rs ;
       rs=db.select(s);
       
       while(rs.next()){
          UserName = rs.getString("UserName");
          Password = rs.getString("Password");
    si = (new Student_Info(UserName,Password));
   login.add(si);
      }
//       for(Student_info std : login){
//        System.out.println(std.UserName);
//         System.out.println(std.Password);
//}
  }
 
   return login;
  
    
   
} 
}
