/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package StudentInfoSystem;


public class Student_Info{
    public String UserName;
    public String Password;
    public String id;
   public String first_name;
   public String last_name;
    public String gender;
   public String course_code;
    public String email;
    public String address;
    public String birthDate;
    int age;
          
    
    Student_Info(String UserName, String Password) {
        this.UserName = UserName;
        this.Password = Password;
    }

    Student_Info(String id,String fname,String lname,int age,String course_code,String email,String address){
       this.first_name=fname;
       this.id=id;
       this.age=age;
       this.last_name=lname;
       this.email=email;
       this.address=address;
       this.course_code=course_code;
       this.gender=gender;
       
   }

  public String  getId(){
       return id;
   }
   public String getFname(){
       return first_name;
   }
   public String getLname(){
       return last_name;
   }
   
  
   
   public String getCourscode(){
       return course_code;
   }
   public String getEmail(){
       return email;
   }
 
   public int getAge(){
       return age;
   }
   
   public String getAddress(){
       return address;
   }
   public String getGender(){
       return gender;
   }
   public String getBirtheDate(){
       return birthDate;
   }
    
}
