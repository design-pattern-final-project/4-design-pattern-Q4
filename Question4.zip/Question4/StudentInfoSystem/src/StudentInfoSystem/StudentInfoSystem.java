
package StudentInfoSystem;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class StudentInfoSystem {

    public static void main(String[] args) {
//     Connection cn = new Connection();
//     cn.getAllCustomers(); 

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new Login().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

    }
    

}