/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package StudentInfoSystem;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Kale
 */
public class Database {
     private static final  Database SINGLE_INSTANCE = new  Database();
      private Database() {}
        private static  com.mysql.jdbc.Connection conn = null;
     
        static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
   static final String DB_URL = "jdbc:mysql://localhost:3306/studentinformation";

   //  Database credentials
   static final String USER = "root";
   static final String PASS = "";
    public static boolean Connect(){
       boolean isConnect = false;
       
       try{
           
      Class.forName(JDBC_DRIVER);

      //STEP 3: Open a connection
      System.out.println("Connecting to a selected database...");
      conn = (Connection) DriverManager.getConnection(DB_URL, USER, PASS);
      System.out.println("Connected database successfully...");
      //STEP 4: Execute a query
      System.out.println("Creating statement...");
//      stmt = (Statement) conn.createStatement();
      System.out.println("Fetching records with condition...");
           isConnect = true;
       }
       catch(Exception e){
        System.out.println("conncetion error");
       }
       return isConnect;
    }
    public static ResultSet select (String query){
      ResultSet result = null;
      try{
        Statement s = conn.createStatement();
        result = s.executeQuery(query);
      }catch(Exception e){
      
      }
      return result;
    }
    public static void showSelect(ResultSet result) throws SQLException{
        if (result!=null){
           try{
            ResultSetMetaData rsmd = (ResultSetMetaData) result.getMetaData();
            int noColumns = rsmd.getColumnCount();
            for(int i = 0;i<noColumns;i++){
              System.out.print(rsmd.getColumnName(i+1) + "\t");
            }
            System.out.println();
            while(result.next()){
               for(int i =0;i<noColumns;i++){
                 System.out.print(result.getString(i+1));
              System.out.println();
              
               }
            }
           }
           catch(Exception e){}
        }
    }
    public static void showSelectedstmt(ResultSet result){
    
          
      
    
    }
    public static int query(String query) {
       int result = -1;
       try{
       Statement s = (Statement)conn.createStatement();
        result = s.executeUpdate(query);
       } catch (Exception e){}
        return result;
    }
    public static void disConnect(){
        try{
         conn.close();
        }
        catch(Exception e){}
    }
     public static Database getInstance() {
      return SINGLE_INSTANCE;
    }
}
